/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication2;

import java.util.Scanner;
import javaapplication2.modelo.Mascota;

/**
 *
 * @author UIS
 */
public class JavaApplication2 {

    static Scanner soul = new Scanner(System.in);

    public static void main(String[] args) {
//        Mascota m1 = new Mascota ("Pedro", "Perro");
//        Mascota m2 = new Mascota("Panchita", "Gato");
//        Mascota m3 = new Mascota("Carla", "Perro");
//        Mascota m4= new Mascota("Nataly", "Gato", 25, 35);
//        
//        
//        
//        //crear mascota 2. mostar datos 3.jugar 4. comer 5.Listar mascotas
//        
//        
//        System.out.println("Digite los datos de su mascota =");
//        
//        System.out.println("Digite el nombre =");
//        String nombre = soul.nextLine();      
//        
//        
//        
        Mascota m5 = new Mascota("Samuel", "Perro", 5, 5);
        Mascota m6 = new Mascota();
        System.out.println(m5);
        System.out.println(m6);     
        
        System.out.println("Digite el nombre de su mascota =");
        String nombre = soul.next();
        m6.setNombre(nombre);
        
        System.out.println("Digite la especie de su mascota =");
        String especie = soul.next();
        m6.setEspecie(especie);
        
        System.out.println("Digite el nivel energico de su mascota =");
        int nivelE = soul.nextInt();
        m6.setNivelEnergico(nivelE);
        
        System.out.println("Digite el nivel de animo de su mascota =");
        int nivelA = soul.nextInt();
        m6.setNivelAnimo(nivelA);
        
        System.out.println(m6);
        
        System.out.println("Quiere jugar con su mascota? (Gana 20 puntos de animo)=");
        String validar1 =soul.next();
        
        
        
    }

}
