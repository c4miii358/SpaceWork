/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2.modelo;

public class Mascota {

    private static m1 Mascota;

    private String nombre;
    private String especie;
    private int nivelEnergico;
    private int nivelAnimo;

    public Mascota(String nombre, String especie) {
        this.nombre = nombre;
        this.especie = especie;
        this.nivelEnergico = 50;
        this.nivelAnimo = 50;
    }

    public Mascota(String nombre, String especie, int nivelEnergico, int nivelAnimo) {
        this.nombre = nombre;
        this.especie = especie;
        this.nivelEnergico = nivelEnergico;
        this.nivelAnimo = nivelAnimo;
    }

    void jugar() {

        if (nivelEnergico > 5) {

            nivelAnimo = nivelAnimo + 5;
            nivelEnergico = nivelEnergico - 5;

            if (nivelAnimo > 100) {
                nivelAnimo = 100;

            }

        } else {

            System.out.println("Su mascota esta muy cansada");

        }
    }

    ;
    void comer() {

        nivelEnergico = nivelEnergico + 5;

        if (nivelEnergico > 100) {
            nivelEnergico = 100;
        }
    }

    ;
    void dormir() {

        nivelEnergico = nivelEnergico + 15;

        if (nivelEnergico > 100) {
            nivelEnergico = 100;
        }

    }

    ;

    @Override
    public String toString() {
        return "Mascota{" + "nombre=" + nombre + ", especie=" + especie + ", nivelEnergico=" + nivelEnergico + ", nivelAnimo=" + nivelAnimo + '}';
    }

    ;
    public Mascota() {
        
        

    }

    
    public static m1 getMascota() {
        return Mascota;
    }

    public static void setMascota(m1 Mascota) {
        Mascota.Mascota = Mascota;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public int getNivelEnergico() {
        return nivelEnergico;
    }

    public void setNivelEnergico(int nivelEnergico) {
        this.nivelEnergico = nivelEnergico;
        if (0<nivelEnergico  || 100>nivelEnergico) {
             nivelEnergico = 100;   
            } else {
        }
    }

    public int getNivelAnimo() {
        return nivelAnimo;
    }

    public void setNivelAnimo(int nivelAnimo) {
        this.nivelAnimo = nivelAnimo;
        if (0<nivelAnimo  || 100>nivelAnimo) {
             nivelAnimo = 100;   
            } else {
        }
    }   
}
