/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication2;

import java.util.Scanner;
import javaapplication2.modelo.Mascota;

/**
 *
 * @author UIS
 */
public class JavaApplication2 {

   static Scanner soul = new Scanner(System.in);
    
    public static void main(String[] args) {
        Mascota m1 = new Mascota ("Pedro", "Perro");
        Mascota m2 = new Mascota("Panchita", "Gato");
        Mascota m3 = new Mascota("Carla", "Perro");
        Mascota m4= new Mascota("Nataly", "Gato", 25, 35);
        
        
        
        //crear mascota 2. mostar datos 3.jugar 4. comer 5.Listar mascotas
        while () {            
            
        }
        System.out.println("Digite los datos de su mascota =");
        
        System.out.println("Digite el nombre =");
        String nombre = soul.nextLine();      
        
        
        
        
        
        
    }
    
    
    
}
