/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;

    

public class NewClass {
    
    // ATRIBUTOS
    public String atributoPublico = "Accesible desde cualquier clase y paquete";
    protected String atributoProtegido = "Accesible en el mismo paquete y subclases";
    String atributoDefault = "Accesible solo dentro del mismo paquete (default)";
    private String atributoPrivado = "Accesible únicamente dentro de esta clase";

    // MÉTODOS
    public void metodoPublico() {
        System.out.println("Método público ejecutado.");
    }

    protected void metodoProtegido() {
        System.out.println("Método protegido ejecutado.");
    }

    void metodoDefault() {
        System.out.println("Método por defecto ejecutado.");
    }

    private void metodoPrivado() {
        System.out.println("Método privado ejecutado.");
    }
}

