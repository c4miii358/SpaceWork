package com.mycompany.mavenproject1;

public class Mavenproject1 {

         
    public static void Peaje() {
   
        System.out.println("Peaje");
        System.out.println("Que cohce esta pasando");
        System.out.println("1.circulo\n2.Camion\n3.Moto\n.4FIN ");
    }
}