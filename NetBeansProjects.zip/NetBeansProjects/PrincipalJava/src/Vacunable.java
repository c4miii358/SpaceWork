
public interface Vacunable {
    public void aplicarVacuna(String nombreVacuna) {
        System.out.println(getNombre() + " recibió la vacuna contra: " + nombreVacuna);
    }

    public String getNombre();
}
