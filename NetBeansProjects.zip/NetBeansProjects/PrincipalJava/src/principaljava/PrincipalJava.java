
package principaljava;


public class PrincipalJava {

   
    public static void main(String[] args) {
        Perro p1 = new Perro("Nataly", 50);
        
    }
    
}
