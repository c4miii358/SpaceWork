
package principaljava;


public class Perro extends Mascota{
    
    public Perro(String nombre, int nivelEnergia) {
        super(nombre, nivelEnergia);
    }

    @Override
    public void comer(){
        setEnergia(getEnergia() + 25);
        System.out.println(getNombre() + " come croquetas de perro. Energía: " + getEnergia());
    }}
    
   