
package principaljava;



public abstract class Mascota {
    
    private String nombre;
    private int nivelEnergia;
    
    
     public Mascota(String nombre, int nivelEnergia) {
        this.nombre = nombre;
        this.nivelEnergia = nivelEnergia;
    }
 

         public void dormir() {
        setEnergia(100);
        System.out.println(this.nombre + " ha dormido y recargó energía al 100%.");
    }
     
     
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEnergia() {
        return nivelEnergia;
    }
    
    public void setEnergia(int energia) {
        this.nivelEnergia = energia;
        if (nivelEnergia < 0) this.nivelEnergia = 0;
        else if (energia > 100) this.nivelEnergia = 100;
        else this.nivelEnergia = nivelEnergia;
    }
     
      public abstract void comer();
}
      
      
