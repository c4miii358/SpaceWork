
public interface Adiestrable {
    public void realizarTruco() {
        System.out.println(getNombre() + " da la pata y se da la vuelta.");
    }

    public String getNombre();
}
