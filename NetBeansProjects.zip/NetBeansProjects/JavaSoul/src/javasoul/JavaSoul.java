/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javasoul;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author AULA 211
 */
public class JavaSoul {

    
    
            
    public static void main(String[] args) {
        
        Random random = new Random(); 
    int numero = random.nextInt(6) + 1;

        System.out.println("Hola "+numero);
        
    }
    
}
