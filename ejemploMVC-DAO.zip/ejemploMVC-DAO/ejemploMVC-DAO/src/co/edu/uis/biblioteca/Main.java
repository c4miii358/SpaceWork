/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.uis.biblioteca;

import co.edu.uis.biblioteca.controller.LibroController;
import co.edu.uis.biblioteca.dao.ILibroDAO;
import co.edu.uis.biblioteca.dao.LibroDAO;
import co.edu.uis.biblioteca.view.LibroViewI;


/**
 *
 * @author Programer
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        
        ILibroDAO dao = new LibroDAO();
        LibroViewI vista = new LibroViewI();
        LibroController controlador = new LibroController(dao, vista);

 vista.setVisible(true);
        
    }
    
}
