/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.uis.biblioteca.controller;

import co.edu.uis.biblioteca.dao.ILibroDAO;
import co.edu.uis.biblioteca.model.Libro;

import co.edu.uis.biblioteca.view.LibroViewI;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Programer
 */
public class LibroController {

    private ILibroDAO dao;
    private LibroViewI vista;

    public LibroController(ILibroDAO dao, LibroViewI vista) {
        this.dao = dao;
        this.vista = vista;
       
        this.vista.addListenerRegistrar(e->registrar());
        
    }
    
        private void registrar() {
            String titulo= vista.getTxtTitulo().getText();
            JOptionPane.showMessageDialog(null, titulo);
            
    }


//    public void iniciar() {
//        String opcion;
//        do {
//            opcion = vista.mostrarMenu();
//            switch (opcion) {
//                case "1" ->
//                    registrar();
//                case "2" ->
//                    listar();
//                case "3" ->
//                    buscar();
//                case "4" ->
//                    cambiarEstadoPrestamo();
//                case "5" ->
//                    eliminar();
//                case "6" ->
//                    vista.mostrarMensaje("¡Saliendo del sistema de biblioteca!");
//                default ->
//                    vista.mostrarMensaje("Opción inválida.");
//            }
//        } while (!opcion.equals("6") );
//    }
//
//    private void registrar() {
//                
//        String isbn = vista.pedirTexto("Ingrese ISBN: ");
//
//        String titulo = vista.pedirTexto("Ingrese Título: ");
//
//        String autor = vista.pedirTexto("Ingrese Autor: ");
//
//        int id = dao.contarLibros() + 1;
//
//        Libro nuevo = new Libro(id, isbn, titulo, autor);
//
//        if (dao.crear(nuevo)) {
//            vista.mostrarMensaje("Libro guardado en el catálogo con éxito.");
//        } else {
//            vista.mostrarMensaje("Error al intentar guardar el libro.");
//        }
//    }
//
//    private void listar() {
//        ArrayList<Libro> lista = dao.obtenerTodos();
//        vista.listarLibros(lista);
//    }
//
//    private void buscar() {
//        String isbn = vista.pedirTexto("Ingrese ISBN del libro a buscar: ");
//        Libro l = dao.buscarPorIsbn(isbn);
//
//        if (l != null) {
//            String estado = l.isDisponible() ? "Disponible" : "Prestado";
//            vista.mostrarMensaje("Libro encontrado: " + l.getTitulo() + " - " + l.getAutor() + " [" + estado + "]");
//        } else {
//            vista.mostrarMensaje("No se encontró ningún libro registrado con el ISBN " + isbn);
//        }
//    }
//
//    private void cambiarEstadoPrestamo() {
//        String isbn = vista.pedirTexto("Ingrese ISBN del libro a gestionar: ");
//        Libro l = dao.buscarPorIsbn(isbn);
//
//        if (l == null) {
//            vista.mostrarMensaje("El libro no se encuentra registrado.");
//            return;
//        }
//
//        if (l.isDisponible()) {
//            l.prestar();
//            vista.mostrarMensaje("El libro '" + l.getTitulo() + "' ha sido PRESTADO.");
//        } else {
//            l.devolver();
//            vista.mostrarMensaje("El libro '" + l.getTitulo() + "' ha sido DEVUELTO y está disponible.");
//        }
//
//        // Guardamos el cambio de estado mediante el DAO
//        dao.actualizar(l);
//    }
//
//    private void eliminar() {
//        String isbn = vista.pedirTexto("Ingrese ISBN del libro a eliminar: ");
//
//        if (dao.eliminar(isbn)) {
//            vista.mostrarMensaje("Libro eliminado del catálogo exitosamente.");
//        } else {
//            vista.mostrarMensaje("No se pudo eliminar el libro o el ISBN no existe.");
//        }
//    }


}
