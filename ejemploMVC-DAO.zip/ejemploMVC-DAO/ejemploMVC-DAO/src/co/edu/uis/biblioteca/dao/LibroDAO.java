/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.uis.biblioteca.dao;

import co.edu.uis.biblioteca.model.Libro;

import java.util.ArrayList;

/**
 *
 * @author Programer
 */
public class LibroDAO implements ILibroDAO {

    private ArrayList<Libro> listaLibros;

    public LibroDAO() {
        this.listaLibros = new ArrayList<>();
    }

    @Override
    public boolean crear(Libro libro) {
        try {

            return listaLibros.add(libro);

        } catch (Exception ex) {

            System.err.println("[DAO Error] Fallo al guardar en lista: " + ex.getMessage());
            return false;
        }
    }

    @Override
    public Libro buscarPorIsbn(String isbn) {
        try {

            for (Libro l : listaLibros) {
                if (l.getIsbn().equalsIgnoreCase(isbn)) {
                    return l;
                }
            }
        } catch (Exception ex) {
            System.err.println("[DAO Error] Fallo al buscar por ISBN: " + ex.getMessage());
        }
        return null;
    }

    @Override
    public ArrayList<Libro> obtenerTodos() {
        try {
            return listaLibros;
        } catch (Exception ex) {
            System.err.println("[DAO Error] Fallo al obtener lista de libros: " + ex.getMessage());
            return null;
        }
    }

    @Override
    public boolean actualizar(Libro libro) {
        try {

            for (int i = 0; i < listaLibros.size(); i++) {
                if (listaLibros.get(i).getIsbn().equalsIgnoreCase(libro.getIsbn())) {
                    listaLibros.set(i, libro);
                    return true;
                }
            }
        } catch (Exception ex) {
            System.err.println("[DAO Error] Fallo al actualizar libro: " + ex.getMessage());
        }
        return false;
    }

    @Override
    public boolean eliminar(String isbn) {
        try {

            return listaLibros.removeIf(l -> l.getIsbn().equalsIgnoreCase(isbn));
        } catch (Exception ex) {
            System.err.println("[DAO Error] Fallo al eliminar libro: " + ex.getMessage());
            return false;
        }

    }


    @Override
    public int contarLibros() {
        
       return listaLibros.size();
    }

}
