/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package co.edu.uis.biblioteca.dao;

import co.edu.uis.biblioteca.model.Libro;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Programer
 */
public interface ILibroDAO {
    
    
    boolean crear(Libro libro);
    Libro buscarPorIsbn(String isbn) ;
    ArrayList<Libro> obtenerTodos() ;
    boolean actualizar(Libro libro);
    boolean eliminar(String isbn);
    int contarLibros();
    
}
