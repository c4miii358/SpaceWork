package DepartamentosAcademicosParcial2Correccion.controller;

import DepartamentosAcademicosParcial2Correccion.dao.IDepartamentoDAO;
import DepartamentosAcademicosParcial2Correccion.dao.IEmpleadoDAO;
import DepartamentosAcademicosParcial2Correccion.model.Departamento;
import DepartamentosAcademicosParcial2Correccion.model.Empleado;
import DepartamentosAcademicosParcial2Correccion.model.ProfesorCatedra;
import DepartamentosAcademicosParcial2Correccion.model.ProfesorPlanta;
import DepartamentosAcademicosParcial2Correccion.view.DepartamentosAcademicosView;
import DepartamentosAcademicosParcial2Correccion.view.VistaDep;
import java.util.ArrayList;

public class DepartamentosAcademicosController {

    private IDepartamentoDAO departamentoDAO;
    private IEmpleadoDAO empleadoDAO;
    private VistaDep vista;

    public DepartamentosAcademicosController(IDepartamentoDAO departamentoDAO, IEmpleadoDAO empleadoDAO, DepartamentosAcademicosView vista) {
        this.departamentoDAO = departamentoDAO;
        this.empleadoDAO = empleadoDAO;
        this.vista = VistaDep;
    }

    public void iniciar() {
        String opcion;
        do {
            opcion = vista.mostrarMenu();
            switch (opcion) {
                case "1" ->
                    registrarDepartamento();
                case "2" ->
                    registrarProfesorPlanta();
                case "3" ->
                    registrarProfesorCatedra();
                case "4" ->
                    reporteGeneral();
                case "5" ->
                    reportePorDepartamento();
                case "6" ->
                    vista.mostrarMensaje("Saliendo del sistema de gestion de nomina UIS...");
                default ->
                    vista.mostrarMensaje("Opcion invalida.");
            }
        } while (!opcion.equals("6"));
    }

    private void registrarDepartamento() {
        String codigo = vista.pedirTexto("Ingrese codigo del departamento (ej: INF): ");

        if (departamentoDAO.buscarPorCodigo(codigo) != null) {
            vista.mostrarMensaje("Ya existe un departamento con ese codigo.");
            return;
        }

        String nombre = vista.pedirTexto("Ingrese nombre del departamento: ");

        Departamento nuevo = new Departamento(codigo, nombre);

        if (departamentoDAO.crear(nuevo)) {
            vista.mostrarMensaje("Departamento registrado con exito.");
        } else {
            vista.mostrarMensaje("Error al intentar guardar el departamento.");
        }
    }

    private void registrarProfesorPlanta() {
        Departamento depto = seleccionarDepartamento();
        if (depto == null) {
            return;
        }

        String documento = vista.pedirTexto("Ingrese documento de identidad: ");
        if (empleadoDAO.buscarPorDocumento(documento) != null) {
            vista.mostrarMensaje("Ya existe un empleado con ese documento.");
            return;
        }

        String nombre = vista.pedirTexto("Ingrese nombre completo: ");
        String correo = vista.pedirTexto("Ingrese correo institucional: ");
        double sueldoBase = pedirDecimal("Ingrese sueldo base: ");
        int cantidadProyectos = pedirEntero("Ingrese cantidad de proyectos de investigacion: ");

        ProfesorPlanta profesor = new ProfesorPlanta(documento, nombre, correo, depto, sueldoBase, cantidadProyectos);

        if (empleadoDAO.crear(profesor)) {
            vista.mostrarMensaje("Profesor de Planta registrado con exito.");
        } else {
            vista.mostrarMensaje("Error al intentar guardar el profesor.");
        }
    }

    private void registrarProfesorCatedra() {
        Departamento depto = seleccionarDepartamento();
        if (depto == null) {
            return;
        }

        String documento = vista.pedirTexto("Ingrese documento de identidad: ");
        if (empleadoDAO.buscarPorDocumento(documento) != null) {
            vista.mostrarMensaje("Ya existe un empleado con ese documento.");
            return;
        }

        String nombre = vista.pedirTexto("Ingrese nombre completo: ");
        String correo = vista.pedirTexto("Ingrese correo institucional: ");
        int horasTrabajadas = pedirEntero("Ingrese horas trabajadas en el mes: ");
        double valorHora = pedirDecimal("Ingrese valor por hora pactado: ");

        ProfesorCatedra profesor = new ProfesorCatedra(documento, nombre, correo, depto, horasTrabajadas, valorHora);

        if (empleadoDAO.crear(profesor)) {
            vista.mostrarMensaje("Profesor de Catedra registrado con exito.");
        } else {
            vista.mostrarMensaje("Error al intentar guardar el profesor.");
        }
    }

    private void reporteGeneral() {
        ArrayList<Empleado> lista = empleadoDAO.obtenerTodos();
        vista.listarEmpleados(lista);
        vista.mostrarTotal("TOTAL NOMINA INSTITUCIONAL", sumarNomina(lista));
    }

    private void reportePorDepartamento() {
        Departamento depto = seleccionarDepartamento();
        if (depto == null) {
            return;
        }

        ArrayList<Empleado> lista = empleadoDAO.obtenerPorDepartamento(depto.getCodigo());
        vista.listarEmpleados(lista);
        vista.mostrarTotal("SUBTOTAL NOMINA " + depto.getNombre(), sumarNomina(lista));
    }

    private Departamento seleccionarDepartamento() {
        ArrayList<Departamento> lista = departamentoDAO.obtenerTodos();

        if (lista.isEmpty()) {
            vista.mostrarMensaje("No hay departamentos registrados. Registre uno primero (opcion 1).");
            return null;
        }

        vista.mostrarDepartamentos(lista);
        String codigo = vista.pedirTexto("Ingrese el codigo del departamento: ");

        Departamento depto = departamentoDAO.buscarPorCodigo(codigo);
        if (depto == null) {
            vista.mostrarMensaje("No existe un departamento con ese codigo.");
        }
        return depto;
    }

    private int pedirEntero(String mensaje) {
        while (true) {
            try {
                int valor = Integer.parseInt(vista.pedirTexto(mensaje).trim());
                if (valor >= 0) {
                    return valor;
                }
                vista.mostrarMensaje("El valor no puede ser negativo.");
            } catch (NumberFormatException ex) {
                vista.mostrarMensaje("Valor invalido. Ingrese un numero entero.");
            }
        }
    }

    private double pedirDecimal(String mensaje) {
        while (true) {
            try {
                double valor = Double.parseDouble(vista.pedirTexto(mensaje).trim());
                if (valor >= 0) {
                    return valor;
                }
                vista.mostrarMensaje("El valor no puede ser negativo.");
            } catch (NumberFormatException ex) {
                vista.mostrarMensaje("Valor invalido. Ingrese un numero.");
            }
        }
    }

    private double sumarNomina(ArrayList<Empleado> lista) {
        double total = 0;
        for (Empleado e : lista) {
            total += e.calcularSalario();
        }
        return total;
    }

}
