package DepartamentosAcademicosParcial2Correccion.model;

public class ProfesorPlanta extends Empleado {

    public static final double BONO_POR_PROYECTO = 500000;

    private double sueldoBase;
    private int cantidadProyectos;

    public ProfesorPlanta(String documento, String nombre, String correo, Departamento departamento,
            double sueldoBase, int cantidadProyectos) {
        super(documento, nombre, correo, departamento);
        this.sueldoBase = sueldoBase;
        this.cantidadProyectos = cantidadProyectos;
    }

    @Override
    public double calcularSalario() {
        return sueldoBase + (cantidadProyectos * BONO_POR_PROYECTO);
    }

    @Override
    public String getTipo() {
        return "Planta";
    }

    public double getSueldoBase() {
        return sueldoBase;
    }

    public void setSueldoBase(double sueldoBase) {
        this.sueldoBase = sueldoBase;
    }

    public int getCantidadProyectos() {
        return cantidadProyectos;
    }

    public void setCantidadProyectos(int cantidadProyectos) {
        this.cantidadProyectos = cantidadProyectos;
    }

}
