package DepartamentosAcademicosParcial2Correccion.model;

public abstract class Empleado {
    private String documento;
    private String nombre;
    private String correo;
    private Departamento departamento;

    public Empleado(String documento, String nombre, String correo, Departamento departamento) {
        this.documento = documento;
        this.nombre = nombre;
        this.correo = correo;
        this.departamento = departamento;
    }

    public double calcularSalario() {
        return 0;
    }

    public String getTipo() {
        return "";
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

}
