package DepartamentosAcademicosParcial2Correccion.model;

public class ProfesorCatedra extends Empleado {

    private int horasTrabajadas;
    private double valorHora;

    public ProfesorCatedra(String documento, String nombre, String correo, Departamento departamento,
            int horasTrabajadas, double valorHora) {
        super(documento, nombre, correo, departamento);
        this.horasTrabajadas = horasTrabajadas;
        this.valorHora = valorHora;
    }

    @Override
    public double calcularSalario() {
        return horasTrabajadas * valorHora;
    }

    @Override
    public String getTipo() {
        return "Catedra";
    }

    public int getHorasTrabajadas() {
        return horasTrabajadas;
    }

    public void setHorasTrabajadas(int horasTrabajadas) {
        this.horasTrabajadas = horasTrabajadas;
    }

    public double getValorHora() {
        return valorHora;
    }

    public void setValorHora(double valorHora) {
        this.valorHora = valorHora;
    }

}
