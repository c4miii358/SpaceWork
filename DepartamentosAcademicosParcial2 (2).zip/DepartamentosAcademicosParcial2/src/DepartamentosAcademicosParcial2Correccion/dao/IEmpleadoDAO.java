package DepartamentosAcademicosParcial2Correccion.dao;

import DepartamentosAcademicosParcial2Correccion.model.Empleado;
import java.util.ArrayList;

public interface IEmpleadoDAO {

    boolean crear(Empleado empleado);

    Empleado buscarPorDocumento(String documento);

    ArrayList<Empleado> obtenerTodos();

    ArrayList<Empleado> obtenerPorDepartamento(String codigoDepto);

}
