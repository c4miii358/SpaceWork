package DepartamentosAcademicosParcial2Correccion.dao;

import DepartamentosAcademicosParcial2Correccion.model.Departamento;
import java.util.ArrayList;

public class DepartamentoDAO implements IDepartamentoDAO {

    private ArrayList<Departamento> listaDepartamentos;

    public DepartamentoDAO() {
        this.listaDepartamentos = new ArrayList<>();
    }

    @Override
    public boolean crear(Departamento departamento) {
        try {
            return listaDepartamentos.add(departamento);
        } catch (Exception ex) {
            System.err.println("[DAO Error] Fallo al guardar departamento: " + ex.getMessage());
            return false;
        }
    }

    @Override
    public Departamento buscarPorCodigo(String codigo) {
        try {
            for (Departamento d : listaDepartamentos) {
                if (d.getCodigo().equalsIgnoreCase(codigo)) {
                    return d;
                }
            }
        } catch (Exception ex) {
            System.err.println("[DAO Error] Fallo al buscar departamento por codigo: " + ex.getMessage());
        }
        return null;
    }

    @Override
    public ArrayList<Departamento> obtenerTodos() {
        return listaDepartamentos;
    }

}
