package DepartamentosAcademicosParcial2Correccion.dao;

import DepartamentosAcademicosParcial2Correccion.model.Departamento;
import java.util.ArrayList;

public interface IDepartamentoDAO {

    boolean crear(Departamento departamento);

    Departamento buscarPorCodigo(String codigo);

    ArrayList<Departamento> obtenerTodos();

}
