package DepartamentosAcademicosParcial2Correccion.dao;

import DepartamentosAcademicosParcial2Correccion.model.Empleado;
import java.util.ArrayList;

public class EmpleadoDAO implements IEmpleadoDAO {

    private ArrayList<Empleado> listaEmpleados;

    public EmpleadoDAO() {
        this.listaEmpleados = new ArrayList<>();
    }

    @Override
    public boolean crear(Empleado empleado) {
        try {
            return listaEmpleados.add(empleado);
        } catch (Exception ex) {
            System.err.println("[DAO Error] Fallo al guardar empleado: " + ex.getMessage());
            return false;
        }
    }

    @Override
    public Empleado buscarPorDocumento(String documento) {
        try {
            for (Empleado e : listaEmpleados) {
                if (e.getDocumento().equalsIgnoreCase(documento)) {
                    return e;
                }
            }
        } catch (Exception ex) {
            System.err.println("[DAO Error] Fallo al buscar empleado por documento: " + ex.getMessage());
        }
        return null;
    }

    @Override
    public ArrayList<Empleado> obtenerTodos() {
        return listaEmpleados;
    }

    @Override
    public ArrayList<Empleado> obtenerPorDepartamento(String codigoDepto) {
        ArrayList<Empleado> resultado = new ArrayList<>();
        try {
            for (Empleado e : listaEmpleados) {
                if (e.getDepartamento().getCodigo().equalsIgnoreCase(codigoDepto)) {
                    resultado.add(e);
                }
            }
        } catch (Exception ex) {
            System.err.println("[DAO Error] Fallo al filtrar empleados por departamento: " + ex.getMessage());
        }
        return resultado;
    }

}
