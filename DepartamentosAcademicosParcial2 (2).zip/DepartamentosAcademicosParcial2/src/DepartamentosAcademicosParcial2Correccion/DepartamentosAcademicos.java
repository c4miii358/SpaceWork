package DepartamentosAcademicosParcial2Correccion;

import DepartamentosAcademicosParcial2Correccion.controller.DepartamentosAcademicosController;
import DepartamentosAcademicosParcial2Correccion.dao.DepartamentoDAO;
import DepartamentosAcademicosParcial2Correccion.dao.EmpleadoDAO;
import DepartamentosAcademicosParcial2Correccion.dao.IDepartamentoDAO;
import DepartamentosAcademicosParcial2Correccion.dao.IEmpleadoDAO;
import DepartamentosAcademicosParcial2Correccion.view.DepartamentosAcademicosView;

public class DepartamentosAcademicos {

    private static DepartamentosAcademicosView VistaDep;

    public static void main(String[] args) {

        IDepartamentoDAO departamentoDAO = new DepartamentoDAO();
        IEmpleadoDAO empleadoDAO = new EmpleadoDAO();
        DepartamentosAcademicosView vista = VistaDep();
        DepartamentosAcademicosController controlador = new DepartamentosAcademicosController(departamentoDAO, empleadoDAO, VistaDep);

        controlador.iniciar();

    }

   

}
